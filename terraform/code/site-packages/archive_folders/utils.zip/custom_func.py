def hello():
    print('a')